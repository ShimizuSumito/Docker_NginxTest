import React, { useEffect, useState } from 'react';
import axios from 'axios';

function App() {
  const [message, setMessage] = useState('');

  useEffect(() => {
    axios.get('http://localhost:8001/api/messageroot')
      .then(response => {
        setMessage(response.data.message);
      })
      .catch(error => {
        console.error(error);
      });
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>アプリケーション表示</h1>
        <h1>これはReactとLaravelを扱うWebアプリケーションです</h1>
        <h1>これはNginxを使用しています</h1>
        {/* <h1>...</h1> */}
        <h1>{message}</h1>
      </header>
    </div>
  );
}

export default App;
